import React, { useEffect, useState } from "react";
import Footer from "../footer";
import Sidebaar from "./Sidebaar";
import {
  mapStateToProps,
  mapDispatchToProps,
} from "../../src/constants/contextProvider";
import { ToastContainer, toast } from "react-toastify";
import { Popconfirm } from "antd";
import MainContainer from "../components/Container";
import { connect, useDispatch, useSelector } from "react-redux";
import { useRouter } from "next/router";
import axios from "axios";
import { MethodNames } from "../../src/constants/methodNames";
import { baseUrl } from "../../src/constants/constants";
import {ViewProjectMasters,ViewReportingManager,stateMasterApi} from "../api/AllApi";
import moment from "moment/moment";
import { useExcelDownloder } from "react-xls";
import * as XLSX from "xlsx";
import ErrorPage from "./ErrorPage";
import Vaildation from "./Vaildation";

const EmployeeReport = (props) => {
  const open = useSelector((state) => state.projectR.sideClick);
  const show = useSelector((state) => state.projectR.showProject);
  const router = useRouter();
  const [searchInput, setSearchInput] = useState("");
  const [searchInput2, setSearchInput2] = useState("");
  const [SearchFliter, setSearchFliter] = useState("");
  const [VieViewPayComponent, setVieViewPayComponent] = useState("");
  const [ViewMasterEmployeeData, setViewMasterEmployeeData] = useState("");
  const [ShowItem, setShowItem] = useState(false);
  const [loding, setLoding] = useState(true);
  const { ExcelDownloder, Type } = useExcelDownloder();
  const [ViewProjectMastersData, setViewProjectMastersData] = useState([]);
  const [ProjectSelect, setProjectSelect] = useState({ ProjectId: "" });
  const [EmpReportsFilter, setEmpReportsFilter] = useState({
    ProjectId: 3,
    FilterType: "",
    FromDate: "",
    ToDate: "",
  });
  // fliter data  in api
  const FilterData = () => {
    const data = {
      ProjectId: EmpReportsFilter.ProjectId,
      FilterType: EmpReportsFilter.FilterType,
      FromDate: EmpReportsFilter.FromDate,
      ToDate: EmpReportsFilter.ToDate,
    };

    console.log("onchange data---", data);
    // setEmpReportsFilter(data)
    MasterEmployeeData(data);
  };


  function exportToExcel(data, fileName) {
    console.log("export data to excel:",data);

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
    //save file;
    let filename="EmployeeReport"+moment().format('DDMMYYYYHHmmss')+'.xls';
    XLSX.writeFile(workbook,filename);
    
  }

  useEffect(() => {
    AllApiCall();
    MasterEmployeeData(0);
  }, []);

  // all project master api call
  const AllApiCall = async () => {
    const ViewProjectMasterss = await ViewProjectMasters();
    setViewProjectMastersData(ViewProjectMasterss.data.ViewMasterProject);
  };

  //   View MasterEmployeeData Type
  const MasterEmployeeData = async () => {

  
    const data = {
      ProjectId: EmpReportsFilter.ProjectId,
      FilterType: EmpReportsFilter.FilterType,
      FromDate: moment(new Date(EmpReportsFilter.FromDate)).format("YYYY/MM/DD"),
      ToDate: moment(new Date(EmpReportsFilter.ToDate)).format("YYYY/MM/DD"),
    };
   if( data.FilterType != ""  && ( data.FromDate == "Invalid date"  ||   data.ToDate == "Invalid date") ){
      toast.error("Please select the date ")
      return
    }
 
    await axios.post(baseUrl + MethodNames.ViewEmployeeOffersReport, data)
      .then((res) => {
        setViewMasterEmployeeData(res.data.ViewEmployeeOffersReport);
      });
  };

  return (
    <div className="h100">
      <ToastContainer />
      <MainContainer>
        <Sidebaar show={show} />
        <div className={open ? "content-page2 vh-100" : "content-page"}>
          <div className="content  ">
            <div className="container-fluid">
              <div className="cardd">
                <div className="col-sm-12  p-2   ">
                  <div className=" row ">
                    <div className="col-sm-12 col-12 col-md-12   ">
                      <div className=" w-100 back-color table_ref_head">
                        <div className="w-100">
                          <h3 className="float-start  fs_15 back-  text-white p-3">
                            Employee Report
                          </h3>
                        </div>
                      </div>
                    </div>
                    <div className="col-sm-12 col-12 col-md-12   ">
                      <div className="fs_15 fw-bold table_ref_head ">
                        <div className="  float-end mt-1 me-1 btn_size me-2 fs_12  btn_h_3 ">
                          <button
                            className=" p-1 bt mt-1 btn-primary btn_size fs_12 fw-none  "
                            onClick={() =>
                              exportToExcel(
                                ViewMasterEmployeeData,
                                "All_Emplyeee_Data.xlsx"
                              )
                            }
                          >
                            Export All Data
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-12 col-md-12 ">
                    <div className="row my-2 px-3">
                      <div className="col-md-2 d-flex">
                        <div class="col-auto">
                          <label for="inputPassword6" class="col-form-label">
                            From Date
                          </label>
                        </div>
                        <div class="col-auto ms-3">
                          <input
                            className="w_90 input_field_head"
                            type="date"
                            value={moment(
                              EmpReportsFilter.FromDate,
                              "MM-DD-YYYY"
                            ).format("YYYY-MM-DD")}
                            // value={NewEmployee.ApprovedDate}
                            // value={moment(NewEmployee.ApprovedDate).format("YYYY-MM-DD")}
                            onChange={(e) =>
                              setEmpReportsFilter({
                                ...EmpReportsFilter,
                                FromDate: moment(
                                  e.target.value,
                                  "YYYY-MM-DD"
                                ).format("MM-DD-YYYY"),
                              })
                            }
                          />
                        </div>
                      </div>
                      <div className="col-md-2 d-flex ms-4">
                        <div class="col-auto">
                          <label for="inputPassword6" class="col-form-label">
                            To Date
                          </label>
                        </div>
                        <div class="col-auto ms-3">
                          <input
                            className="w_90 input_field_head"
                            type="date"
                            value={moment(
                              EmpReportsFilter.ToDate,
                              "MM-DD-YYYY"
                            ).format("YYYY-MM-DD")}
                            // value={NewEmployee.ApprovedDate}
                            // value={moment(NewEmployee.ApprovedDate).format("YYYY-MM-DD")}
                            onChange={(e) =>
                              setEmpReportsFilter({
                                ...EmpReportsFilter,
                                ToDate: moment(
                                  e.target.value,
                                  "YYYY-MM-DD"
                                ).format("MM-DD-YYYY"),
                              })
                            }
                          />
                        </div>
                      </div>
                      <div className="col-md-3">
                        <div className="  float-end    fs_12  btn_h_3  ">
                          Project Select
                          <select
                            class="form-select w-50 ms-3 w_178 "
                            value={EmpReportsFilter.ProjectId}
                            onChange={(e) => {
                              setEmpReportsFilter({
                                ...EmpReportsFilter,
                                ProjectId: e.target.value,
                              });
                            }}
                            aria-label="Default select example"
                          >
                            {/* <option value={1} selected>
                              Select Project
                            </option> */}
                            {ViewProjectMastersData &&
                              ViewProjectMastersData.map((i, key) => (
                                <option selected key={key} value={i.ProjectId}>
                                  {i.ProjectName}
                                </option>
                              ))}
                          </select>
                        </div>
                      </div>
                      <div className="col-md-3">
                        <div className="  float-end      fs_12  btn_h_3  ">
                          Filter Type
                          <select
                            class="form-select w-50 ms-3  w_178"
                            value={EmpReportsFilter.FilterType}
                            onChange={(e) => {
                              setEmpReportsFilter({
                                ...EmpReportsFilter,
                                FilterType: e.target.value,
                              });
                            }}
                            aria-label="Default select example"
                          >
                            {/* <option value={0} selected>
                              Filter Type
                            </option> */}
                            <option value="Offer Letter Date">
                              Offer Letter Date
                            </option>
                            <option value="Projected Joining Date">
                              Projected Joining Date
                            </option>
                            <option value="Creation Date">Creation Date</option>
                          </select>
                        </div>
                      </div>
                      <div className="col-md-1">
                        {" "}
                        <button
                          className="btn btn-primary fs_10 px-4 "
                          type="button "
                          onClick={() => FilterData()}
                        >
                          show
                        </button>
                      </div>
                    </div>
                  </div>
                  <div className="table-responsive">
                    {ViewMasterEmployeeData.length > 0 ? (
                      <table className="table-responsive">
                        <tbody>
                          <tr>
                            <td className="text-center td_size px-5 ">
                              {" "}
                              EmpId
                            </td>
                            <th className="text-center td_size"> Name</th>
                            <th className="text-center td_size">
                              {" "}
                              ProjectName
                            </th>
                            {/* <th className="text-center td_size">PayCompDescription </th> */}
                            <th className="text-center td_size">Mobile </th>
                            <th className="text-center td_size ">
                              Designation_Name{" "}
                            </th>
                            <th className="text-center td_size">
                              Projected_DOJ{" "}
                            </th>
                            <th className="text-center td_size">
                              Notice_Period
                            </th>
                            <th className="text-center td_size">
                              Location_Name
                            </th>
                            <th className="text-center td_size">Per_Address</th>
                            <th className="text-center td_size">Per_State</th>
                            <th className="text-center td_size">Per_City</th>
                            <th className="text-center td_size">Per_Pincode</th>
                            <th className="text-center td_size">
                              Current_Address
                            </th>
                            <th className="text-center td_size">
                              Current_State
                            </th>
                            <th className="text-center td_size">
                              Current_Pincode
                            </th>
                            <th className="text-center td_size">
                              Marital_Status
                            </th>
                            <th className="text-center td_size">Father_Name</th>
                            <th className="text-center td_size">Gender</th>
                            <th className="text-center td_size">
                              Marital_Status
                            </th>
                            <th className="text-center td_size">Father_Name</th>
                            <th className="text-center td_size">
                              Notice_Period
                            </th>
                            <th className="text-center td_size">
                              Probation_Period
                            </th>
                            <th className="text-center td_size">
                              Offer_LetterDate
                            </th>
                            <th className="text-center td_size">DOB</th>
                            <th className="text-center td_size">Email</th>
                            <th className="text-center td_size">AadharNo</th>
                            <th className="text-center td_size">Pancard</th>
                            <th className="text-center td_size">BankName</th>
                            <th className="text-center td_size">
                              Bank_BranchName
                            </th>
                            <th className="text-center td_size">
                              Bank_AccountNo
                            </th>
                            <th className="text-center td_size">IFSC_Code</th>
                            <th className="text-center td_size">ID_Proof</th>
                            <th className="text-center td_size">Basic</th>
                            <th className="text-center td_size">HRA</th>
                          </tr>

                          <>
                            {ViewMasterEmployeeData &&
                              ViewMasterEmployeeData.map((i, key) => {
                                return (
                                  <>
                                    <tr key={key}>
                                      <td style={{ textAlign: "center" }}>
                                        {i.EmpId}
                                      </td>
                                      <td className="text-center">
                                        {i.EmpName}
                                      </td>
                                      <td className="text-center">
                                        {i.ProjectName}
                                      </td>
                                      <td className="text-center">
                                        {i.Mobile}
                                      </td>
                                      <td className="text-center">
                                        {i.DesignationName}
                                      </td>
                                      <td className="text-center">
                                        {moment(
                                          new Date(i.ProjectedDOJ)
                                        ).format("MM/DD/YYYY")}{" "}
                                      </td>
                                      <td className="text-center">
                                        {i.NoticePeriod}
                                      </td>
                                      <td className="text-center">
                                        {i.LocationName}
                                      </td>
                                      <td className="text-center">
                                        {i.PerAddress}
                                      </td>
                                      <td className="text-center">
                                        {i.PerState}
                                      </td>
                                      <td className="text-center">
                                        {i.PerCity}
                                      </td>
                                      <td className="text-center">
                                        {i.PerPincode}
                                      </td>
                                      <td className="text-center">
                                        {i.CurrentAddress}
                                      </td>
                                      <td className="text-center">
                                        {i.CurState}
                                      </td>
                                      {/* <td className="text-center">{i.CurrentCity}</td> */}
                                      <td className="text-center">
                                        {i.CurrentPincode}
                                      </td>
                                      <td className="text-center">
                                        {i.MaritalStatus}
                                      </td>
                                      <td className="text-center">
                                        {i.FatherName}
                                      </td>
                                      <td className="text-center">
                                        {i.Gender}
                                      </td>
                                      <td className="text-center">
                                        {i.MaritalStatus}
                                      </td>
                                      <td className="text-center">
                                        {i.FatherName}
                                      </td>
                                      <td className="text-center">
                                        {i.NoticePeriod}
                                      </td>
                                      <td className="text-center">
                                        {i.ProbationPeriod}
                                      </td>
                                      <td className="text-center">
                                        {moment(
                                          new Date(i.OfferLetterDate)
                                        ).format("MM/DD/YYYY")}
                                      </td>
                                      <td className="text-center">
                                        {moment(new Date(i.DOB)).format(
                                          "MM/DD/YYYY"
                                        )}
                                      </td>
                                      <td className="text-center">{i.Email}</td>
                                      <td className="text-center">
                                        {i.AadharNo}
                                      </td>
                                      <td className="text-center">
                                        {i.Pancard}
                                      </td>
                                      <td className="text-center">
                                        {i.BankName}
                                      </td>
                                      <td className="text-center">
                                        {i.BankBranchName}
                                      </td>
                                      <td className="text-center">
                                        {i.BankAccountNo}
                                      </td>
                                      <td className="text-center">
                                        {i.IFSCCode}
                                      </td>
                                      <td className="text-center">
                                        {i.IDProof}
                                      </td>
                                      <td className="text-center">{i.Basic}</td>
                                      <td className="text-center">{i.HRA}</td>
                                    </tr>
                                  </>
                                );
                              })}
                          </>
                        </tbody>
                      </table>
                    ) : (
                      <ErrorPage />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </MainContainer>
    </div>
  );
};

export default connect(mapStateToProps, mapDispatchToProps)(EmployeeReport);
